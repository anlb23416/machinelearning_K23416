import pandas as pd

dataframe=pd.read_excel('../dataset/Sales_Transaction/SalesTransactions.xlsx')

print(dataframe)